<?php

/**
 * Unused class, kept for compatibilty.
 *
 * @deprecated Will be removed after SMW 1.9; do not use
 */
class SMWStringLengthException extends MWException {
}

/**
 * This class is an alias for SMWDIBlob, kept for compatibility.
 *
 * @since 1.6
 * @deprecated Will be removed after SMW 1.9; use SMWDIBlob instead
 *
 * @author Markus Krötzsch
 * @ingroup SMWDataItems
 */
class SMWDIString extends SMWDIBlob {
}
